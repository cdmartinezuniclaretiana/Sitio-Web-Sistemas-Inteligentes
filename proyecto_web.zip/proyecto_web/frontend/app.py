"""
Frontend Streamlit - Sistema de Análisis y Predicción de Servicios Turísticos (Chocó)
Interfaz interactiva 100% con componentes nativos de Streamlit para máxima estabilidad y compatibilidad.
"""

import os
import io
import json
import requests
import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

# Configuración de página de Streamlit
st.set_page_config(
    page_title="Predicción de Servicios Turísticos - Chocó",
    page_icon="🏖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inicializar Session State
if "api_url" not in st.session_state:
    st.session_state.api_url = "http://127.0.0.1:8000"
if "last_validation" not in st.session_state:
    st.session_state.last_validation = None
if "last_df" not in st.session_state:
    st.session_state.last_df = None
if "last_file_name" not in st.session_state:
    st.session_state.last_file_name = None
if "last_predictions" not in st.session_state:
    st.session_state.last_predictions = None
if "eda_data" not in st.session_state:
    st.session_state.eda_data = None
if "eda_df" not in st.session_state:
    st.session_state.eda_df = None


# --- FUNCIONES DE COMUNICACIÓN CON EL BACKEND ---
def check_api_health(base_url: str):
    """Verifica si la API de FastAPI está en línea."""
    try:
        resp = requests.get(f"{base_url}/status", timeout=5)
        if resp.status_code == 200:
            return True, resp.json()
        return False, None
    except Exception:
        return False, None

def api_validate_file(base_url: str, file_bytes: bytes, file_name: str, is_training: bool = False):
    """Envía el archivo a validar al endpoint /validate."""
    try:
        files = {"file": (file_name, file_bytes)}
        params = {"is_training": is_training}
        resp = requests.post(f"{base_url}/validate", files=files, params=params, timeout=60)
        if resp.status_code == 200:
            return True, resp.json()
        try:
            return False, resp.json()
        except Exception:
            return False, resp.text
    except Exception as e:
        return False, f"Error al conectar con el backend: {str(e)}"

def api_generate_eda(base_url: str, file_bytes: bytes, file_name: str):
    """Solicita el análisis EDA al endpoint /eda."""
    try:
        files = {"file": (file_name, file_bytes)}
        resp = requests.post(f"{base_url}/eda", files=files, timeout=90)
        if resp.status_code == 200:
            return True, resp.json()
        try:
            return False, resp.json()
        except Exception:
            return False, resp.text
    except Exception as e:
        return False, f"Error al conectar con el backend para EDA: {str(e)}"

def api_predict_dataset(base_url: str, file_bytes: bytes, file_name: str):
    """Solicita la predicción al endpoint /predict."""
    try:
        files = {"file": (file_name, file_bytes)}
        resp = requests.post(f"{base_url}/predict", files=files, timeout=90)
        if resp.status_code == 200:
            return True, resp.json()
        try:
            return False, resp.json()
        except Exception:
            return False, resp.text
    except Exception as e:
        return False, f"Error al conectar con el backend para predicción: {str(e)}"

def api_retrain_model(base_url: str, file_bytes: bytes, file_name: str):
    """Solicita el reentrenamiento al endpoint /retrain."""
    try:
        files = {"file": (file_name, file_bytes)}
        resp = requests.post(f"{base_url}/retrain", files=files, timeout=120)
        if resp.status_code == 200:
            return True, resp.json()
        try:
            return False, resp.json()
        except Exception:
            return False, resp.text
    except Exception as e:
        return False, f"Error al conectar con el backend para reentrenamiento: {str(e)}"

def api_list_reports(base_url: str):
    """Consulta la lista de reportes en /reports."""
    try:
        resp = requests.get(f"{base_url}/reports", timeout=5)
        if resp.status_code == 200:
            return resp.json().get("reports", [])
        return []
    except Exception:
        return []

def api_download_report_bytes(base_url: str, filename: str):
    """Descarga los bytes de un archivo de reporte."""
    try:
        resp = requests.get(f"{base_url}/download/{filename}", timeout=15)
        if resp.status_code == 200:
            return resp.content
        return None
    except Exception:
        return None


# --- SIDEBAR DE NAVEGACIÓN Y MONITOREO ---
with st.sidebar:
    st.title("🏖️ Chocó Turismo ML")
    st.caption("Observatorio Predictivo de Oferta Turística")
    st.divider()

    # Configuración de URL del Backend
    st.subheader("⚙️ Conexión Backend")
    api_url = st.text_input("URL de la API (FastAPI)", value=st.session_state.api_url)
    st.session_state.api_url = api_url

    # Monitor de Conexión
    is_online, system_info = check_api_health(api_url)
    if is_online:
        st.success("🟢 API Conectada y Lista")
        st.write(f"**Modelo:** `{system_info.get('active_model_file')}`")
        st.write(f"**Versión:** `{system_info.get('active_version')}`")
        st.write(f"**Accuracy:** `{system_info.get('metric_value') * 100:.1f}%`")
    else:
        st.error("🔴 API Desconectada")
        st.caption("Verifica que la terminal con Uvicorn esté ejecutándose.")

    st.divider()
    st.info("💡 **Consejo:** Si tu navegador tiene activo el traductor automático de Google/Edge, desactívalo para `localhost:8501` para evitar interferencias visuales.")


# --- ENCABEZADO PRINCIPAL ---
st.title("🏛️ Gobernación del Chocó - Observatorio de Turismo")
st.caption("Plataforma de Inteligencia Artificial para la Detección y Planificación de Servicios Faltantes (Alojamiento, Agencia, Gastronomía)")
st.divider()

# --- NAVEGACIÓN POR PESTAÑAS (MÁXIMA ESTABILIDAD) ---
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "1. 📤 Validación de Archivos",
    "2. 📊 Explorador EDA",
    "3. 🤖 Inferencia y Predicciones",
    "4. 🔄 Reentrenamiento de Modelo",
    "5. 📁 Centro de Reportes"
])


# =========================================================================
# PESTAÑA 1: VALIDACIÓN DE ARCHIVOS
# =========================================================================
with tab1:
    st.header("1. Carga y Validación Estricta de Datos")
    st.write(
        "Suba un archivo en formato **CSV o Excel** para evaluar su compatibilidad con el modelo. "
        "Si sube la base cruda del RNT, el sistema la detectará y agregará automáticamente por municipio."
    )

    uploaded_file = st.file_uploader(
        "Seleccione el archivo a validar (CSV o Excel):",
        type=["csv", "xlsx", "xls"],
        key="uploader_validation"
    )

    if uploaded_file is not None:
        file_bytes = uploaded_file.getvalue()
        file_name = uploaded_file.name

        if st.button("🔍 Validar Compatibilidad", key="btn_validate", type="primary"):
            with st.spinner("Validando esquema, tipos y reglas de dominio..."):
                success, result = api_validate_file(st.session_state.api_url, file_bytes, file_name, is_training=False)

            if not success:
                st.error(f"Error en la validación: {result}")
            else:
                st.session_state.last_validation = result
                st.session_state.last_file_name = file_name
                try:
                    for enc in ["utf-8-sig", "utf-8", "latin-1"]:
                        try:
                            st.session_state.last_df = pd.read_csv(io.BytesIO(file_bytes), sep=None, engine="python", encoding=enc)
                            break
                        except Exception:
                            continue
                except Exception:
                    pass

        # Mostrar resultados si existen
        if st.session_state.last_validation:
            res = st.session_state.last_validation
            status_text = res.get("status", "DESCONOCIDO")

            # Aviso si fue procesado desde la base cruda del RNT
            if res.get("was_raw_rnt"):
                agg = res.get("aggregation_info", {})
                st.info(
                    f"🔄 **Base Cruda del RNT Detectada y Agregada Automáticamente:** "
                    f"Se procesaron {agg.get('original_rows', 0)} registros individuales de prestadores "
                    f"y se agruparon en {agg.get('aggregated_municipalities', 0)} municipios compatibles con el modelo."
                )

            st.subheader("Resultado de la Validación:")
            if status_text == "COMPATIBLE":
                st.success("✅ **ESTADO: COMPATIBLE** (Listo para Inferencia)")
            elif status_text == "COMPATIBLE CON ADVERTENCIAS":
                st.warning("⚠️ **ESTADO: COMPATIBLE CON ADVERTENCIAS** (Se puede procesar)")
            else:
                st.error("🚫 **ESTADO: INCOMPATIBLE** (Requiere corrección)")

            # Métricas rápidas
            det = res.get("details", {})
            st.divider()
            c1, c2, c3 = st.columns(3)
            c1.metric("Total Registros", det.get("total_rows", 0))
            c2.metric("Total Columnas", det.get("total_columns", 0))
            c3.metric("¿Apto para Predicción?", "SÍ" if res.get("can_predict") else "NO")

            if res.get("errors"):
                st.markdown("#### 🚨 Errores Críticos:")
                for err in res["errors"]:
                    st.error(f"• {err}")

            if res.get("warnings"):
                st.markdown("#### ⚠️ Advertencias:")
                for warn in res["warnings"]:
                    st.warning(f"• {warn}")

            st.divider()
            rep_filename = res.get("report_file")
            json_str = json.dumps(res, indent=2, ensure_ascii=False)
            st.download_button(
                label="📥 Descargar Reporte de Validación (JSON)",
                data=json_str,
                file_name=rep_filename or "reporte_validacion.json",
                mime="application/json",
                key="dl_val_report"
            )


# =========================================================================
# PESTAÑA 2: EXPLORADOR DE DATOS (EDA)
# =========================================================================
with tab2:
    st.header("2. Análisis Exploratorio de Datos (EDA) Dinámico")
    st.write("Inspeccione distribuciones, valores atípicos, matriz de correlación y calidad de datos.")

    uploaded_eda_file = st.file_uploader(
        "Cargue un archivo CSV o Excel para explorar:",
        type=["csv", "xlsx", "xls"],
        key="uploader_eda"
    )

    if uploaded_eda_file is not None:
        file_bytes_eda = uploaded_eda_file.getvalue()
        file_name_eda = uploaded_eda_file.name

        if st.button("📊 Generar Análisis EDA Dinámico", type="primary", key="btn_run_eda"):
            with st.spinner("Calculando estadísticas descriptivas y correlaciones..."):
                ok, eda_data = api_generate_eda(st.session_state.api_url, file_bytes_eda, file_name_eda)

            if not ok:
                st.error(f"Error al procesar el EDA: {eda_data}")
            else:
                st.session_state.eda_data = eda_data
                try:
                    for enc in ["utf-8-sig", "utf-8", "latin-1"]:
                        try:
                            st.session_state.eda_df = pd.read_csv(io.BytesIO(file_bytes_eda), sep=None, engine="python", encoding=enc)
                            break
                        except Exception:
                            continue
                except Exception:
                    pass

    if st.session_state.eda_data:
        eda = st.session_state.eda_data

        if eda.get("was_raw_rnt"):
            agg = eda.get("aggregation_info", {})
            st.info(
                f"🔄 **Base Cruda del RNT Detectada y Agregada:** "
                f"Se procesaron {agg.get('original_rows', 0)} registros individuales de prestadores "
                f"y el EDA se consolidó a nivel de los {agg.get('aggregated_municipalities', 0)} municipios."
            )

        # KPIs Principales
        k1, k2, k3, k4 = st.columns(4)
        k1.metric("Total de Filas", eda.get("total_rows", 0))
        k2.metric("Total de Columnas", eda.get("total_cols", 0))
        k3.metric("Filas Duplicadas", eda.get("duplicates", 0))
        k4.metric("Variables Numéricas", len(eda.get("stats_summary", {})))

        st.divider()
        st.subheader("📋 Resumen de Columnas y Diagnóstico de Nulos")
        cols_df = pd.DataFrame(eda.get("columns_info", []))
        st.dataframe(cols_df, use_container_width=True)

        st.divider()
        st.subheader("📈 Estadísticas Descriptivas")
        stats_dict = eda.get("stats_summary", {})
        if stats_dict:
            stats_df = pd.DataFrame(stats_dict).T
            st.dataframe(stats_df, use_container_width=True)

            # Gráficos dinámicos interactivos
            st.divider()
            st.subheader("📊 Distribución y Detección de Dispersión")
            num_cols = list(stats_dict.keys())
            selected_col = st.selectbox("Seleccione una variable para graficar:", num_cols, key="sb_eda_col")

            df_plot = st.session_state.get("eda_df") if st.session_state.get("eda_df") is not None else st.session_state.get("last_df")
            if selected_col and df_plot is not None and selected_col in df_plot.columns:
                g1, g2 = st.columns(2)
                with g1:
                    fig_hist, ax_hist = plt.subplots(figsize=(6, 3.8))
                    col_vals = pd.to_numeric(df_plot[selected_col], errors='coerce').dropna()
                    if len(col_vals) > 0:
                        sns.histplot(col_vals, kde=True, color="#2563eb", ax=ax_hist)
                    ax_hist.set_title(f"Histograma: {selected_col}")
                    st.pyplot(fig_hist)
                with g2:
                    fig_box, ax_box = plt.subplots(figsize=(6, 3.8))
                    col_vals = pd.to_numeric(df_plot[selected_col], errors='coerce').dropna()
                    if len(col_vals) > 0:
                        sns.boxplot(x=col_vals, color="#38bdf8", ax=ax_box)
                    ax_box.set_title(f"Boxplot: {selected_col}")
                    st.pyplot(fig_box)

        # Matriz de Correlación
        corrs = eda.get("correlations", {})
        if corrs:
            st.divider()
            st.subheader("🔥 Matriz de Correlación de Pearson")
            corr_df = pd.DataFrame(corrs)
            fig_corr, ax_corr = plt.subplots(figsize=(8, 4.5))
            sns.heatmap(corr_df, annot=True, cmap="Blues", fmt=".2f", linewidths=0.5, ax=ax_corr)
            st.pyplot(fig_corr)

        # Enlace para descargar el reporte HTML generado
        st.divider()
        html_rep = eda.get("html_report_file")
        if html_rep:
            html_bytes = api_download_report_bytes(st.session_state.api_url, html_rep)
            if html_bytes:
                st.download_button(
                    label="📥 Descargar Reporte Completo en HTML",
                    data=html_bytes,
                    file_name=html_rep,
                    mime="text/html",
                    key="dl_eda_html"
                )


# =========================================================================
# PESTAÑA 3: INFERENCIA Y PREDICCIONES
# =========================================================================
with tab3:
    st.header("3. Módulo de Predicción de Servicio Faltante")
    st.write(
        "Cargue un conjunto de datos (agregado o crudo del RNT). "
        "El modelo activo calculará qué servicio turístico (`Alojamiento`, `Agencia` o `Gastronomía`) es prioritario fortalecer."
    )

    pred_file = st.file_uploader(
        "Subir archivo para inferencia:",
        type=["csv", "xlsx", "xls"],
        key="uploader_pred"
    )

    if pred_file is not None:
        p_bytes = pred_file.getvalue()
        p_name = pred_file.name

        if st.button("🚀 Ejecutar Predicciones con Pipeline Activo", type="primary", key="btn_run_pred"):
            with st.spinner("Procesando inferencia con el modelo activo..."):
                ok, pred_res = api_predict_dataset(st.session_state.api_url, p_bytes, p_name)

            if not ok:
                st.error("No se pudo completar la inferencia.")
                if isinstance(pred_res, dict):
                    st.json(pred_res)
                else:
                    st.write(pred_res)
            else:
                st.session_state.last_predictions = pred_res
                st.success("✅ ¡Inferencia completada exitosamente!")

    if st.session_state.last_predictions:
        p_data = st.session_state.last_predictions
        summary = p_data.get("summary", {})

        if p_data.get("was_raw_rnt"):
            st.info("🔄 **Inferencia a Nivel Municipal desde Base Cruda RNT:** El archivo fue agrupado por Municipio para predecir la demanda.")

        st.divider()
        m1, m2, m3 = st.columns(3)
        m1.metric("Total Predicciones", summary.get("total_predicciones", 0))
        m2.metric("Modelo Utilizado", summary.get("modelo_utilizado", "N/A"))
        m3.metric("Confianza Promedio", f"{summary.get('confianza_promedio_pct', 0)}%")

        # Gráfico de distribución de servicios faltantes predichos
        class_dist = summary.get("distribucion_clases", {})
        if class_dist:
            st.subheader("📊 Demanda Prioritaria Identificada por Municipio:")
            c_chart1, c_chart2 = st.columns([3, 2])
            with c_chart1:
                dist_df = pd.DataFrame(list(class_dist.items()), columns=["Servicio Faltante", "Cantidad de Municipios"])
                fig_bar, ax_bar = plt.subplots(figsize=(6, 3))
                palette = {"Alojamiento": "#f59e0b", "Agencia": "#3b82f6", "Gastronomía": "#10b981"}
                colors = [palette.get(c, "#64748b") for c in dist_df["Servicio Faltante"]]
                ax_bar.bar(dist_df["Servicio Faltante"], dist_df["Cantidad de Municipios"], color=colors)
                ax_bar.set_ylabel("Municipios")
                ax_bar.set_title("Demanda Prioritaria de Infraestructura Turística")
                st.pyplot(fig_bar)

            with c_chart2:
                st.write("**Desglose de Conteo:**")
                st.dataframe(dist_df, use_container_width=True)

        st.divider()
        st.subheader("📋 Muestra de Resultados con Predicciones")
        preview_rows = p_data.get("preview", [])
        if preview_rows:
            pred_df = pd.DataFrame(preview_rows)
            st.dataframe(pred_df, use_container_width=True)

        report_file = p_data.get("report_file")
        if report_file:
            csv_bytes = api_download_report_bytes(st.session_state.api_url, report_file)
            if csv_bytes:
                st.download_button(
                    label="📥 Descargar Dataset Completo con Predicciones (CSV)",
                    data=csv_bytes,
                    file_name=report_file,
                    mime="text/csv",
                    key="dl_pred_csv"
                )


# =========================================================================
# PESTAÑA 4: REENTRENAMIENTO Y VERSIONAMIENTO
# =========================================================================
with tab4:
    st.header("4. Reentrenamiento y Versionamiento de Modelos")
    st.write(
        "Suba un archivo con datos reales etiquetados (que contenga la variable `Servicio_Faltante`). "
        "Si supera o iguala el Accuracy actual, promoverá automáticamente la versión del modelo."
    )

    retrain_file = st.file_uploader(
        "Subir dataset etiquetado para reentrenamiento:",
        type=["csv", "xlsx", "xls"],
        key="uploader_retrain"
    )

    if retrain_file is not None:
        r_bytes = retrain_file.getvalue()
        r_name = retrain_file.name

        if st.button("⚡ Iniciar Reentrenamiento y Evaluación", type="primary", key="btn_run_retrain"):
            with st.spinner("Entrenando modelo candidato y comparando métricas..."):
                ok, retrain_res = api_retrain_model(st.session_state.api_url, r_bytes, r_name)

            if not ok:
                st.error("No se pudo completar el reentrenamiento.")
                st.json(retrain_res)
            else:
                st.session_state.retrain_result = retrain_res

    if "retrain_result" in st.session_state and st.session_state.retrain_result:
        r_data = st.session_state.retrain_result
        promoted = r_data.get("promoted", False)

        st.divider()
        st.subheader("🎯 Resultado de la Evaluación:")

        if promoted:
            st.success(f"🎉 {r_data.get('message')}")
        else:
            st.warning(f"⚠️ {r_data.get('message')}")

        c_comp1, c_comp2, c_comp3 = st.columns(3)
        prev_acc = r_data.get("previous_accuracy", r_data.get("active_accuracy", 0))
        new_acc = r_data.get("new_accuracy", r_data.get("candidate_accuracy", 0))
        delta = r_data.get("accuracy_delta", 0)

        c_comp1.metric("Accuracy Modelo Previo", f"{prev_acc * 100:.2f}%")
        c_comp2.metric("Accuracy Modelo Candidato", f"{new_acc * 100:.2f}%", delta=f"{delta * 100:.2f}%")
        c_comp3.metric("Decisión de Versión", "ACTUALIZADO ✅" if promoted else "MANTENIDO ⏸️")

        clf_rep = r_data.get("classification_report", {})
        if clf_rep:
            st.divider()
            st.subheader("📊 Métricas Detalladas de Clasificación")
            report_df = pd.DataFrame(clf_rep).T
            st.dataframe(report_df.round(3), use_container_width=True)

        cm_data = r_data.get("confusion_matrix", {})
        if cm_data and "matrix" in cm_data:
            st.divider()
            st.subheader("🔲 Matriz de Confusión:")
            labels = cm_data.get("labels", [])
            matrix = np.array(cm_data.get("matrix", []))
            fig_cm, ax_cm = plt.subplots(figsize=(5, 3.5))
            sns.heatmap(matrix, annot=True, fmt="d", cmap="Blues", xticklabels=labels, yticklabels=labels, ax=ax_cm)
            ax_cm.set_xlabel("Predicción")
            ax_cm.set_ylabel("Valor Real")
            st.pyplot(fig_cm)


# =========================================================================
# PESTAÑA 5: CENTRO DE REPORTES
# =========================================================================
with tab5:
    st.header("5. Centro de Descarga de Reportes Generados")
    st.write("Acceda a los reportes de validación (JSON), análisis exploratorio (HTML) y archivos de predicción (CSV).")

    reports = api_list_reports(st.session_state.api_url)

    if not reports:
        st.info("No se han generado reportes aún. Ejecute una validación, un EDA o una predicción para ver archivos aquí.")
    else:
        st.write(f"Se encontraron **{len(reports)}** archivos disponibles en el servidor:")
        rep_df = pd.DataFrame(reports)
        st.dataframe(rep_df[["filename", "extension", "size_bytes", "modified_at"]], use_container_width=True)

        st.divider()
        st.subheader("Descargar un Reporte Específico:")
        selected_rep = st.selectbox("Seleccione el archivo que desea descargar:", [r["filename"] for r in reports], key="sb_rep_select")

        if selected_rep:
            rep_bytes = api_download_report_bytes(st.session_state.api_url, selected_rep)
            if rep_bytes:
                mime_type = "text/csv" if selected_rep.endswith(".csv") else "text/html" if selected_rep.endswith(".html") else "application/json"
                st.download_button(
                    label=f"📥 Descargar '{selected_rep}'",
                    data=rep_bytes,
                    file_name=selected_rep,
                    mime=mime_type,
                    key="dl_rep_selected"
                )
