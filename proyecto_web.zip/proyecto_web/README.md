# 🏖️ Sistema de Predicción y Planificación Turística - Departamento del Chocó

Sistema web integral (**Frontend Streamlit + Backend API FastAPI + Machine Learning Pipeline**) diseñado para predecir la necesidad de infraestructura y servicios turísticos faltantes (**Alojamiento, Agencia de Viajes o Gastronomía**) en los municipios del Departamento del Chocó, Colombia.

---

## 🏛️ Arquitectura del Proyecto

```text
proyecto_web/
├── backend/
│   ├── __init__.py
│   ├── main.py              # API RESTful con FastAPI (endpoints /validate, /eda, /predict, /retrain, etc.)
│   ├── ml_pipeline.py       # Carga dinámica del modelo activo e inferencia estricta (sin refit)
│   ├── validation.py        # Motor de validación estricta de esquemas, tipos y rangos lógicos
│   └── train.py             # Reentrenamiento, evaluación comparativa de Accuracy y versionamiento
├── frontend/
│   └── app.py               # Aplicación interactiva moderna en Streamlit (5 módulos)
├── models/
│   ├── metadata.json        # Reglas de validación, métricas, versión activa e historial
│   ├── model_v1.pkl         # Modelo serializado activo (RandomForestClassifier Pipeline)
│   └── versiones/           # Historial y respaldos de versiones anteriores
├── data/
│   ├── sample_para_predecir.csv    # Dataset de prueba sin target para inferencia
│   ├── sample_para_reentrenar.csv  # Dataset con etiquetas para reentrenamiento
│   └── sample_incompatible.csv     # Dataset con errores para probar el validador
├── reports/                 # Almacén de reportes generados (CSV con predicciones, HTML EDA, JSON)
├── create_initial_model.py  # Script de inicialización y generación de datos sintéticos
├── test_system.py           # Script de pruebas automáticas e integración
├── requirements.txt         # Dependencias del entorno Python
└── README.md                # Manual técnico y guía de despliegue
```

---

## ⚙️ Características Principales

1. **Validación Estricta Multi-Fase (`validation.py` & `metadata.json`)**:
   - **Esquema:** Valida la presencia de las features obligatorias: `Total_Camas`, `Total_Habitaciones`, `Total_Empleados`, `Alojamiento`, `Agencia`, `Gastronomía`.
   - **Tipos de Datos:** Detecta texto o caracteres inválidos en columnas numéricas.
   - **Contenido:** Alerta sobre valores nulos y porcentaje de faltantes.
   - **Dominio:** Bloquea valores imposibles (ej. camas o habitaciones negativas).
   - Clasificación en tres estados: `COMPATIBLE`, `COMPATIBLE CON ADVERTENCIAS` e `INCOMPATIBLE`.

2. **EDA Dinámico (`backend/main.py` y `frontend/app.py`)**:
   - Detección de duplicados, conteo de nulos, estadísticas descriptivas completas, histogramas con curva de densidad, diagramas de cajas (boxplots) y mapa de calor de correlaciones.
   - Exportación de reporte interactivo en formato **HTML**.

3. **Inferencia en Lote Segura (`ml_pipeline.py`)**:
   - Carga el artefacto serializado del modelo activo sin reajustar los transformadores.
   - Genera la columna `Prediccion_Servicio_Faltante` y el porcentaje de `Confianza_Prediccion`.
   - Exporta automáticamente el dataset resultante con timestamp en `reports/` y permite su descarga inmediata en CSV.

4. **Reentrenamiento con Versionamiento Automático (`train.py`)**:
   - Recibe nuevos datos etiquetados con `Servicio_Faltante`.
   - Entrena un modelo candidato y evalúa su métrica en un conjunto de prueba estratificado.
   - **Regla de Promoción:** Si el `Accuracy` del candidato es mayor o igual al modelo actual, se archiva el anterior en `models/versiones/backup_...`, se serializa como `model_v{N}.pkl` y se actualiza `metadata.json` marcándolo como `activo`.

---

## 🚀 Guía de Instalación y Ejecución

### 1. Requisitos Previos
- Python 3.10 o superior instalado.

### 2. Configurar Entorno Virtual (Recomendado)
Abre tu terminal en la carpeta del proyecto:
```bash
cd proyecto_web
python -m venv venv

# En Windows (PowerShell):
.\venv\Scripts\Activate.ps1

# En Linux / macOS:
source venv/bin/activate
```

### 3. Instalar Dependencias
```bash
pip install -r requirements.txt
```

### 4. Inicializar el Modelo y Datos de Prueba
Ejecuta el script que crea el modelo inicial `model_v1.pkl`, los metadatos y los archivos CSV de demostración:
```bash
python create_initial_model.py
```

---

## 🖥️ Ejecución de la Aplicación

Para utilizar la aplicación completa se requieren dos terminales: una para el Backend (FastAPI) y otra para el Frontend (Streamlit).

### Terminal 1: Iniciar el Backend (FastAPI)
```bash
uvicorn backend.main:app --reload --port 8000
```
- API en vivo: [http://127.0.0.1:8000](http://127.0.0.1:8000)
- Documentación interactiva Swagger: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

### Terminal 2: Iniciar el Frontend (Streamlit)
```bash
streamlit run frontend/app.py --server.port 8501
```
- Interfaz gráfica: [http://localhost:8501](http://localhost:8501)

---

## 🧪 Flujo de Pruebas Paso a Paso

1. **Página 1 (Validación de Archivos):**
   - Sube `data/sample_para_predecir.csv` -> Observa el semáforo **Verde (COMPATIBLE)**.
   - Sube `data/sample_incompatible.csv` -> Observa el semáforo **Rojo (INCOMPATIBLE)** con el detalle exacto de columnas faltantes y errores de tipo texto.
   - Descarga el reporte de validación en JSON.

2. **Página 2 (Explorador EDA):**
   - Carga cualquier dataset y genera el análisis dinámico.
   - Explora las correlaciones, los gráficos de dispersión y descarga el reporte en formato **HTML**.

3. **Página 3 (Predicciones ML):**
   - Carga `data/sample_para_predecir.csv`.
   - Haz clic en **"Ejecutar Predicciones"**.
   - Analiza el gráfico de barras con la demanda de servicios por municipio y descarga el CSV con las predicciones y scores de confianza.

4. **Página 4 (Reentrenamiento y Versionamiento):**
   - Carga `data/sample_para_reentrenar.csv`.
   - Haz clic en **"Iniciar Reentrenamiento y Evaluación"**.
   - Observa la comparativa cara a cara de métricas y la promoción automática a la siguiente versión del modelo (ej. `model_v2.pkl`).

5. **Página 5 (Centro de Reportes):**
   - Consulta el historial de todos los reportes generados en el servidor y descárgalos con un solo clic.

---

## 🔒 Manejo de Errores y Robustez
- Todo el backend implementa bloques `try-except` con respuestas JSON estructuradas y códigos HTTP adecuados (`400 Bad Request`, `404 Not Found`, `500 Internal Error`).
- El frontend en Streamlit captura excepciones de red y muestra alertas amigables al usuario mediante componentes nativos (`st.error`, `st.warning`, `st.info`), evitando la exposición de trazas técnicas de Python en la interfaz.
