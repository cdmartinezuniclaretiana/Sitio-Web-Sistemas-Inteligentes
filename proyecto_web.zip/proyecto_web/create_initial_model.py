"""
Script de Inicialización del Modelo Base y Conjuntos de Datos de Prueba.
Genera datos sintéticos realistas basados en los municipios del Departamento del Chocó,
entrena un pipeline RandomForestClassifier inicial (model_v1.pkl), actualiza metadata.json
y crea archivos CSV de prueba para validación, predicción y reentrenamiento.
"""

import json
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"
DATA_DIR = BASE_DIR / "data"
MODELS_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Lista de municipios del Chocó
MUNICIPIOS_CHOCO = [
    ("Quibdó", "27001", "Capital"),
    ("Nuquí", "27495", "Costa Pacífica"),
    ("Bahía Solano", "27075", "Costa Pacífica"),
    ("Acandí", "27006", "Golfo de Urabá"),
    ("Capurganá", "27007", "Caribe Chocoano"),
    ("Istmina", "27361", "San Juan"),
    ("Condoto", "27205", "San Juan"),
    ("Tadó", "27787", "San Juan"),
    ("Bajo Baudó", "27077", "Costa Pacífica"),
    ("Medio Baudó", "27430", "Baudó"),
    ("Alto Baudó", "27025", "Baudó"),
    ("Bojayá", "27099", "Atrato"),
    ("Riosucio", "27615", "Bajo Atrato"),
    ("Unguía", "27800", "Golfo de Urabá"),
    ("Carmen del Darién", "27150", "Bajo Atrato"),
    ("Cértegui", "27160", "San Juan"),
    ("Bagadó", "27073", "Atrato"),
    ("Lloró", "27413", "Atrato"),
    ("Medio Atrato", "27425", "Atrato"),
    ("Medio San Juan", "27450", "San Juan"),
    ("Nóvita", "27491", "San Juan"),
    ("Sipí", "27745", "San Juan"),
    ("Unión Panamericana", "27810", "San Juan"),
    ("Juradó", "27372", "Costa Pacífica Norte"),
    ("El Cantón del San Pablo", "27250", "San Juan"),
    ("Atrato", "27050", "Atrato"),
    ("San José del Palmar", "27660", "Occidente"),
    ("Río Iró", "27580", "San Juan"),
    ("Río Quito", "27600", "Atrato"),
    ("Belén de Bajirá", "27086", "Urabá")
]


def generate_synthetic_choco_data(n_samples: int = 120, seed: int = 42) -> pd.DataFrame:
    """Genera datos verosímiles de oferta turística en municipios del Chocó."""
    np.random.seed(seed)
    data = []

    for i in range(n_samples):
        muni_idx = i % len(MUNICIPIOS_CHOCO)
        muni_name, dane, subregion = MUNICIPIOS_CHOCO[muni_idx]

        # Simulación diferenciada por tamaño y vocación turística
        is_capital = (muni_name == "Quibdó")
        is_beach = ("Pacífica" in subregion or "Caribe" in subregion or "Urabá" in subregion)

        if is_capital:
            habitaciones = int(np.random.normal(320, 40))
            camas = int(habitaciones * np.random.uniform(1.8, 2.3))
            empleados = int(habitaciones * np.random.uniform(0.6, 0.9))
            alojamiento = int(np.random.normal(35, 5))
            agencias = int(np.random.normal(12, 3))
            gastronomia = int(np.random.normal(60, 8))
        elif is_beach:
            habitaciones = int(np.random.normal(110, 30))
            camas = int(habitaciones * np.random.uniform(2.1, 2.8))
            empleados = int(habitaciones * np.random.uniform(0.4, 0.7))
            alojamiento = int(np.random.normal(22, 6))
            agencias = int(np.random.normal(5, 2))
            gastronomia = int(np.random.normal(18, 5))
        else:
            habitaciones = int(np.random.normal(45, 18))
            camas = int(habitaciones * np.random.uniform(1.5, 2.2))
            empleados = int(habitaciones * np.random.uniform(0.2, 0.5))
            alojamiento = int(np.random.normal(8, 3))
            agencias = int(np.random.normal(1, 1))
            gastronomia = int(np.random.normal(10, 4))

        # Asegurar valores mínimos positivos
        habitaciones = max(5, habitaciones)
        camas = max(habitaciones, camas)
        empleados = max(3, empleados)
        alojamiento = max(1, alojamiento)
        agencias = max(0, agencias)
        gastronomia = max(1, gastronomia)

        # Regla lógica para Servicio Faltante en turismo del Chocó:
        # Si hay muchas camas pero casi no hay agencias -> Falta Agencia
        # Si hay pocas camas/habitaciones relativo a gastronomía -> Falta Alojamiento
        # Si hay alojamiento y agencias pero muy pocos restaurantes -> Falta Gastronomía
        ratio_aloj_gast = alojamiento / (gastronomia + 1e-5)
        ratio_camas_agen = camas / (agencias + 1)

        # Introducir algo de ruido realista
        if np.random.rand() < 0.12:
            servicio_faltante = np.random.choice(["Alojamiento", "Agencia", "Gastronomía"])
        elif agencias <= 2 or ratio_camas_agen > 80:
            servicio_faltante = "Agencia"
        elif ratio_aloj_gast < 0.35 or camas < 70:
            servicio_faltante = "Alojamiento"
        else:
            servicio_faltante = "Gastronomía"

        data.append({
            "Municipio": muni_name,
            "Codigo_DANE": dane,
            "Total_Camas": camas,
            "Total_Habitaciones": habitaciones,
            "Total_Empleados": empleados,
            "Alojamiento": alojamiento,
            "Agencia": agencias,
            "Gastronomía": gastronomia,
            "Servicio_Faltante": servicio_faltante
        })

    return pd.DataFrame(data)


def main():
    print("=" * 65)
    print("INICIALIZACIÓN DEL SISTEMA DE MACHINE LEARNING - CHOCÓ")
    print("=" * 65)

    # 1. Generar datos sintéticos realistas
    df_full = generate_synthetic_choco_data(n_samples=180, seed=101)
    print(f"-> Dataset sintético generado con {len(df_full)} registros.")

    feature_cols = [
        "Total_Camas",
        "Total_Habitaciones",
        "Total_Empleados",
        "Alojamiento",
        "Agencia",
        "Gastronomía"
    ]
    target_col = "Servicio_Faltante"

    X = df_full[feature_cols]
    y = df_full[target_col]

    # 2. Partición Train/Test
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    # 3. Entrenar Pipeline
    pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", RandomForestClassifier(
            n_estimators=100,
            max_depth=6,
            random_state=42,
            class_weight="balanced"
        ))
    ])

    print("-> Entrenando RandomForestClassifier...")
    pipeline.fit(X_train, y_train)

    y_pred = pipeline.predict(X_test)
    accuracy = float(accuracy_score(y_test, y_pred))
    print(f"-> Accuracy obtenido en conjunto de prueba: {accuracy * 100:.2f}%")

    # 4. Guardar modelo activo v1
    model_v1_path = MODELS_DIR / "model_v1.pkl"
    joblib.dump(pipeline, model_v1_path)
    print(f"-> Modelo serializado guardado en: {model_v1_path}")

    # 5. Actualizar metadata.json con la métrica real
    metadata_path = MODELS_DIR / "metadata.json"
    with open(metadata_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    meta["active_model_file"] = "model_v1.pkl"
    meta["active_version"] = "1.0.0"
    meta["metric_value"] = round(accuracy, 4)
    meta["versions_history"][0]["metric_value"] = round(accuracy, 4)

    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    print(f"-> Metadatos actualizados en: {metadata_path}")

    # 6. Generar datasets de prueba para el usuario en data/
    # Archivo 1: Para Predecir (Sin columna Servicio_Faltante, incluye identificador Municipio)
    df_para_predecir = generate_synthetic_choco_data(n_samples=30, seed=2024).drop(columns=["Servicio_Faltante"])
    predict_csv = DATA_DIR / "sample_para_predecir.csv"
    df_para_predecir.to_csv(predict_csv, index=False, encoding="utf-8")
    print(f"-> Archivo de prueba para predicción: {predict_csv}")

    # Archivo 2: Para Reentrenar (Con columna Servicio_Faltante y nuevos registros)
    df_para_reentrenar = generate_synthetic_choco_data(n_samples=250, seed=555)
    retrain_csv = DATA_DIR / "sample_para_reentrenar.csv"
    df_para_reentrenar.to_csv(retrain_csv, index=False, encoding="utf-8")
    print(f"-> Archivo de prueba para reentrenamiento: {retrain_csv}")

    # Archivo 3: Incompatible (Para probar validaciones estrictas: falta Total_Camas y tiene texto en Habitaciones)
    df_incompatible = df_para_predecir.copy().drop(columns=["Total_Camas"])
    df_incompatible["Total_Habitaciones"] = df_incompatible["Total_Habitaciones"].astype(object)
    df_incompatible.loc[0:2, "Total_Habitaciones"] = "ERROR_TEXTO"
    incomp_csv = DATA_DIR / "sample_incompatible.csv"
    df_incompatible.to_csv(incomp_csv, index=False, encoding="utf-8")
    print(f"-> Archivo de prueba incompatible (para testing): {incomp_csv}")

    print("=" * 65)
    print("INICIALIZACIÓN COMPLETADA CON ÉXITO.")
    print("=" * 65)


if __name__ == "__main__":
    main()
