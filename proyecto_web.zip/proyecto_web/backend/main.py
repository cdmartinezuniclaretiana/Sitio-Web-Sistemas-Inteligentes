"""
FastAPI Backend - Sistema de Predicción de Servicio Turístico Faltante (Chocó)
Proporciona endpoints RESTful para validación, análisis exploratorio (EDA),
predicciones en lote, reentrenamiento con versionamiento y exportación de reportes.
"""

import io
import os
import math
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional

import pandas as pd
import numpy as np
from fastapi import FastAPI, UploadFile, File, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

from backend.validation import DataValidator
from backend.ml_pipeline import MLPredictor
from backend.train import ModelTrainer
from backend.rnt_preprocessor import RNTPreprocessor

# Directorios base
BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"
REPORTS_DIR = BASE_DIR / "reports"
METADATA_PATH = MODELS_DIR / "metadata.json"
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title="API de Predicción de Servicios Turísticos - Chocó",
    description="Backend para validación de datos, inferencia con Random Forest y reentrenamiento continuo.",
    version="1.0.0"
)

# Configuración CORS para Streamlit y otros clientes
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicializar servicios
validator = DataValidator(str(METADATA_PATH))
predictor = None
try:
    predictor = MLPredictor(str(METADATA_PATH), str(MODELS_DIR))
except Exception:
    predictor = None

trainer = ModelTrainer(str(METADATA_PATH), str(MODELS_DIR))


def sanitize_for_json(obj):
    """
    Reemplaza recursivamente valores NaN, Infinity y tipos de NumPy
    para que sean 100% compatibles con la serialización JSON de Starlette/FastAPI.
    """
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return round(obj, 4)
    elif isinstance(obj, dict):
        return {str(k): sanitize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [sanitize_for_json(v) for v in obj]
    elif isinstance(obj, (np.floating, np.float32, np.float64)):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return round(float(obj), 4)
    elif isinstance(obj, (np.integer, np.int32, np.int64)):
        return int(obj)
    return obj


def read_uploaded_file(file: UploadFile, contents: bytes) -> pd.DataFrame:
    """
    Lee archivos CSV o Excel con detección automática de delimitador (, ; \t |)
    y múltiples codificaciones (UTF-8 con BOM, UTF-8, Latin-1, CP1252).
    """
    filename = file.filename.lower()
    try:
        if filename.endswith(".csv"):
            encodings_to_try = ["utf-8-sig", "utf-8", "latin-1", "cp1252"]
            for enc in encodings_to_try:
                try:
                    # Intento con motor python que autodetecta separador (coma o punto y coma)
                    df = pd.read_csv(io.BytesIO(contents), sep=None, engine="python", encoding=enc)
                    if len(df.columns) > 1 or len(df) > 0:
                        return df
                except Exception:
                    continue

            # Fallback en caso de que el motor python falle con líneas irregulares
            for enc in ["utf-8-sig", "latin-1"]:
                try:
                    return pd.read_csv(io.BytesIO(contents), encoding=enc, on_bad_lines="skip")
                except Exception:
                    continue

            raise ValueError("No fue posible leer el archivo CSV con las codificaciones habituales.")
        elif filename.endswith((".xls", ".xlsx")):
            return pd.read_excel(io.BytesIO(contents))
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Formato no compatible: '{file.filename}'. Use archivos .csv, .xlsx o .xls."
            )
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error al procesar el archivo: {str(e)}"
        )


@app.get("/")
def home():
    """Ruta raíz de bienvenida y estado de la API."""
    return {
        "status": "online",
        "service": "API de Predicción de Servicios Turísticos Faltantes (Chocó)",
        "version": "1.0.0",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "docs_url": "/docs"
    }


@app.get("/status")
def get_system_status():
    """Consulta el estado del modelo activo, versión y métricas."""
    validator.reload_metadata()
    meta = validator.metadata
    return {
        "status": "ready",
        "active_model_file": meta.get("active_model_file"),
        "active_version": meta.get("active_version"),
        "metric_name": meta.get("metric_name", "Accuracy"),
        "metric_value": meta.get("metric_value"),
        "target_variable": meta.get("target_variable"),
        "target_classes": meta.get("target_classes"),
        "required_features": meta.get("features", {}).get("required", []),
        "last_updated": meta.get("last_updated")
    }


@app.get("/metadata")
def get_metadata():
    """Retorna el contenido completo del archivo metadata.json."""
    validator.reload_metadata()
    return validator.metadata


@app.post("/validate")
async def validate_file(file: UploadFile = File(...), is_training: bool = False):
    """
    Endpoint para validación estricta de esquemas y tipos de datos.
    Detecta automáticamente si el archivo es la base cruda del RNT y lo preprocesa/agrega
    antes de validar la compatibilidad con el modelo.
    """
    contents = await file.read()
    df_raw = read_uploaded_file(file, contents)

    # 1. Detección y agregación automática de base cruda del RNT si aplica
    df, was_aggregated, agg_info = RNTPreprocessor.process_dataframe(df_raw)

    # 2. Validación estricta con los metadatos
    validator.reload_metadata()
    validation_res = validator.validate_dataset(df, is_training=is_training)

    validation_res["was_raw_rnt"] = was_aggregated
    if was_aggregated:
        validation_res["aggregation_info"] = agg_info
        validation_res["warnings"].insert(
            0,
            f"Base de datos cruda del RNT detectada ({agg_info['original_rows']} registros individuales). "
            f"Se ejecutó agregación automática a nivel de {agg_info['aggregated_municipalities']} municipios."
        )

    # Generar reporte de validación en JSON dentro de reports/
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_filename = f"reporte_validacion_{timestamp}.json"
    report_path = REPORTS_DIR / report_filename
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(validation_res, f, indent=2, ensure_ascii=False)

    validation_res["report_file"] = report_filename
    validation_res["filename"] = file.filename
    return sanitize_for_json(validation_res)


@app.post("/eda")
async def generate_eda(file: UploadFile = File(...)):
    """
    Endpoint para Análisis Exploratorio de Datos (EDA) Dinámico.
    Si detecta base cruda del RNT, la agrega primero a nivel de municipio.
    Genera estadísticas descriptivas, análisis de valores nulos,
    matriz de correlación y exporta un reporte HTML estilizado.
    """
    contents = await file.read()
    df_raw = read_uploaded_file(file, contents)

    # Detección y agregación automática de RNT
    df, was_aggregated, agg_info = RNTPreprocessor.process_dataframe(df_raw)

    if df.empty:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El dataset está vacío. No es posible generar el EDA."
        )

    # Métricas generales
    total_rows, total_cols = df.shape
    duplicates_count = int(df.duplicated().sum())

    # Información de columnas y nulos
    columns_info = []
    for col in df.columns:
        null_count = int(df[col].isna().sum())
        null_pct = round((null_count / total_rows) * 100, 2)
        dtype_str = str(df[col].dtype)
        unique_vals = int(df[col].nunique())
        columns_info.append({
            "columna": col,
            "tipo": dtype_str,
            "nulos": null_count,
            "porcentaje_nulos": null_pct,
            "valores_unicos": unique_vals
        })

    # Estadísticas descriptivas de variables numéricas
    numeric_df = df.select_dtypes(include=[np.number])
    stats_summary = {}
    correlations = {}

    if not numeric_df.empty:
        # describe().to_dict() agrupa por columna (ej. Total_Camas, Total_Habitaciones, etc.)
        desc = numeric_df.describe().to_dict()
        for col, values in desc.items():
            def safe_float(val, default=0.0):
                if val is None or pd.isna(val) or (isinstance(val, float) and (math.isnan(val) or math.isinf(val))):
                    return default
                return round(float(val), 2)

            # Skewness segura
            skew_val = 0.0
            try:
                col_clean = pd.to_numeric(numeric_df[col], errors='coerce').dropna()
                if len(col_clean) > 2:
                    s = float(col_clean.skew())
                    skew_val = 0.0 if (math.isnan(s) or math.isinf(s)) else round(s, 2)
            except Exception:
                skew_val = 0.0

            stats_summary[col] = {
                "count": int(values.get("count", 0)),
                "mean": safe_float(values.get("mean")),
                "std": safe_float(values.get("std")),
                "min": safe_float(values.get("min")),
                "25%": safe_float(values.get("25%")),
                "50%": safe_float(values.get("50%")),
                "75%": safe_float(values.get("75%")),
                "max": safe_float(values.get("max")),
                "skewness": skew_val
            }

        # Matriz de correlación
        if len(numeric_df.columns) > 1:
            try:
                corr_matrix = numeric_df.corr().fillna(0).round(3)
                correlations = corr_matrix.replace({np.nan: 0.0}).to_dict()
            except Exception:
                correlations = {}

    # Generación de Reporte HTML
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    html_filename = f"eda_reporte_{timestamp}.html"
    html_path = REPORTS_DIR / html_filename

    html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte EDA Dinámico - Turismo Chocó</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 30px; background-color: #f8fafc; color: #1e293b; }}
        h1, h2, h3 {{ color: #0f172a; }}
        .header {{ background: #1e40af; color: white; padding: 20px; border-radius: 8px; margin-bottom: 25px; }}
        .kpi-container {{ display: flex; gap: 15px; margin-bottom: 25px; flex-wrap: wrap; }}
        .kpi-card {{ background: white; padding: 15px 25px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); flex: 1; min-width: 160px; }}
        .kpi-card h4 {{ margin: 0; color: #64748b; font-size: 14px; text-transform: uppercase; }}
        .kpi-card p {{ margin: 8px 0 0; font-size: 24px; font-weight: bold; color: #2563eb; }}
        table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; margin-bottom: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }}
        th, td {{ padding: 12px 15px; text-align: left; border-bottom: 1px solid #e2e8f0; }}
        th {{ background-color: #f1f5f9; font-weight: 600; color: #475569; }}
        tr:hover {{ background-color: #f8fafc; }}
        .tag {{ padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }}
        .tag-ok {{ background-color: #dcfce7; color: #166534; }}
        .tag-warn {{ background-color: #fef9c3; color: #854d0e; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Reporte EDA - Análisis Exploratorio de Datos</h1>
        <p>Archivo analizado: <strong>{file.filename}</strong> | Fecha de generación: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
    </div>

    <div class="kpi-container">
        <div class="kpi-card">
            <h4>Total Registros</h4>
            <p>{total_rows:,}</p>
        </div>
        <div class="kpi-card">
            <h4>Total Columnas</h4>
            <p>{total_cols}</p>
        </div>
        <div class="kpi-card">
            <h4>Filas Duplicadas</h4>
            <p>{duplicates_count}</p>
        </div>
        <div class="kpi-card">
            <h4>Variables Numéricas</h4>
            <p>{len(numeric_df.columns)}</p>
        </div>
    </div>

    <h2>1. Resumen de Columnas y Calidad de Datos</h2>
    <table>
        <thead>
            <tr>
                <th>Columna</th>
                <th>Tipo de Dato</th>
                <th>Valores Nulos</th>
                <th>% Nulos</th>
                <th>Valores Únicos</th>
            </tr>
        </thead>
        <tbody>
            {"".join([f"<tr><td><strong>{c['columna']}</strong></td><td>{c['tipo']}</td><td>{c['nulos']}</td><td>{c['porcentaje_nulos']}%</td><td>{c['valores_unicos']}</td></tr>" for c in columns_info])}
        </tbody>
    </table>

    <h2>2. Estadísticas Descriptivas (Variables Numéricas)</h2>
    <table>
        <thead>
            <tr>
                <th>Variable</th>
                <th>Media</th>
                <th>Desv. Est.</th>
                <th>Mín</th>
                <th>25%</th>
                <th>Mediana</th>
                <th>75%</th>
                <th>Máx</th>
                <th>Asimetría</th>
            </tr>
        </thead>
        <tbody>
            {"".join([f"<tr><td><strong>{col}</strong></td><td>{s['mean']}</td><td>{s['std']}</td><td>{s['min']}</td><td>{s['25%']}</td><td>{s['50%']}</td><td>{s['75%']}</td><td>{s['max']}</td><td>{s['skewness']}</td></tr>" for col, s in stats_summary.items()])}
        </tbody>
    </table>
</body>
</html>
"""
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    result_payload = {
        "filename": file.filename,
        "was_raw_rnt": was_aggregated,
        "aggregation_info": agg_info if was_aggregated else None,
        "total_rows": total_rows,
        "total_cols": total_cols,
        "duplicates": duplicates_count,
        "columns_info": columns_info,
        "stats_summary": stats_summary,
        "correlations": correlations,
        "html_report_file": html_filename
    }
    return sanitize_for_json(result_payload)


@app.post("/predict")
async def predict_dataset(file: UploadFile = File(...)):
    """
    Endpoint para inferencia con el modelo activo.
    1. Si es base cruda del RNT, la agrega a nivel de Municipio.
    2. Valida el archivo.
    3. Ejecuta predicción por lotes sin reajuste.
    4. Retorna predicciones y enlace de descarga CSV.
    """
    contents = await file.read()
    df_raw = read_uploaded_file(file, contents)

    # Detección y agregación automática de RNT
    df, was_aggregated, agg_info = RNTPreprocessor.process_dataframe(df_raw)

    # Validar primero
    validator.reload_metadata()
    val_res = validator.validate_dataset(df, is_training=False)
    if not val_res["can_predict"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "message": "El archivo es INCOMPATIBLE y no puede ser procesado por el modelo.",
                "errors": val_res["errors"],
                "warnings": val_res["warnings"]
            }
        )

    # Cargar predictor
    global predictor
    if predictor is None:
        predictor = MLPredictor(str(METADATA_PATH), str(MODELS_DIR))
    else:
        predictor.reload()

    try:
        df_predicted, summary, report_filename = predictor.predict(df)
        
        # Muestra de las primeras 20 filas para visualización rápida en UI
        preview_data = df_predicted.head(20).replace({np.nan: None}).to_dict(orient="records")

        summary["fue_base_cruda_rnt"] = was_aggregated
        if was_aggregated:
            summary["info_agregacion"] = agg_info

        return sanitize_for_json({
            "success": True,
            "was_raw_rnt": was_aggregated,
            "aggregation_info": agg_info if was_aggregated else None,
            "summary": summary,
            "report_file": report_filename,
            "preview": preview_data,
            "total_records": len(df_predicted)
        })
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error durante el proceso de inferencia: {str(e)}"
        )


@app.post("/retrain")
async def retrain_model(file: UploadFile = File(...)):
    """
    Endpoint de Reentrenamiento y Versionamiento.
    - Recibe un dataset nuevo con labels ('Servicio_Faltante').
    - Si es base cruda, agrega por municipio.
    - Valida compatibilidad para entrenamiento.
    - Entrena modelo candidato y compara Accuracy.
    - Si es mejor o igual, actualiza versión y activa el nuevo modelo.
    """
    contents = await file.read()
    df_raw = read_uploaded_file(file, contents)

    df, was_aggregated, agg_info = RNTPreprocessor.process_dataframe(df_raw)

    result = trainer.retrain(df)

    if not result.get("success", False):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=result
        )

    if was_aggregated:
        result["was_raw_rnt"] = True
        result["aggregation_info"] = agg_info

    # Recargar predictor si fue promovido
    if result.get("promoted", False):
        global predictor
        if predictor is not None:
            predictor.reload()

    return sanitize_for_json(result)


@app.get("/reports")
def list_reports():
    """Lista todos los reportes generados disponibles para descarga."""
    files = []
    if REPORTS_DIR.exists():
        for p in sorted(REPORTS_DIR.iterdir(), key=os.path.getmtime, reverse=True):
            if p.is_file():
                stat = p.stat()
                files.append({
                    "filename": p.name,
                    "extension": p.suffix.lower(),
                    "size_bytes": stat.st_size,
                    "modified_at": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                })
    return {"reports": files}


@app.get("/download/{filename}")
def download_report(filename: str):
    """Permite descargar un archivo generado de la carpeta reports/."""
    file_path = REPORTS_DIR / filename
    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"El archivo '{filename}' no fue encontrado en los reportes."
        )

    media_type = "text/csv" if filename.endswith(".csv") else "text/html" if filename.endswith(".html") else "application/json"
    return FileResponse(
        path=file_path,
        media_type=media_type,
        filename=filename
    )
