"""
Módulo de Detección y Preprocesamiento de Bases Crudas del RNT (Registro Nacional de Turismo).
Transforma automáticamente bases a nivel de establecimiento (filas individuales)
en la estructura agregada a nivel de Municipio esperada por el modelo.
"""

import re
import unicodedata
from typing import Tuple, Dict, Any, Optional
import pandas as pd
import numpy as np


def normalize_text(text: str) -> str:
    """Normaliza cadenas eliminando tildes, espacios extras y pasando a mayúsculas."""
    if not isinstance(text, str):
        text = str(text) if pd.notna(text) else ""
    text = text.strip().upper()
    return "".join(
        c for c in unicodedata.normalize("NFD", text)
        if unicodedata.category(c) != "Mn"
    )


class RNTPreprocessor:
    """Detecta y agrega archivos crudos del RNT a nivel de Municipio."""

    # Columnas esperadas por el modelo ya agregado
    MODEL_REQUIRED_COLUMNS = {
        "Total_Camas",
        "Total_Habitaciones",
        "Total_Empleados",
        "Alojamiento",
        "Agencia",
        "Gastronomía"
    }

    @classmethod
    def is_already_aggregated(cls, df: pd.DataFrame) -> bool:
        """Verifica si el dataset ya cuenta con las columnas agregadas del modelo."""
        normalized_df_cols = {normalize_text(col) for col in df.columns}
        normalized_required = {normalize_text(col) for col in cls.MODEL_REQUIRED_COLUMNS}
        # Si ya contiene todas las columnas requeridas (o al menos 5 de 6), ya está agregado
        matches = normalized_required.intersection(normalized_df_cols)
        return len(matches) >= 5

    @classmethod
    def _find_column(cls, df: pd.DataFrame, patterns: list) -> Optional[str]:
        """Busca una columna que coincida con alguno de los patrones regex."""
        for col in df.columns:
            norm_col = normalize_text(col)
            for pat in patterns:
                if re.search(pat, norm_col):
                    return col
        return None

    @classmethod
    def is_raw_rnt(cls, df: pd.DataFrame) -> bool:
        """
        Determina si un DataFrame corresponde a la base de datos cruda del RNT.
        Busca columnas típicas como MUNICIPIO, CAMAS, CATEGORIA, NUM_EMP, etc.
        """
        if cls.is_already_aggregated(df):
            return False

        has_municipio = cls._find_column(df, [r"^MUNICIPIO", r"^CIUDAD", r"NOMBRE.*MUNI", r"^MPIO"]) is not None
        has_categoria = cls._find_column(df, [r"^CATEGORIA", r"SUB.*CATEGORIA", r"TIPO.*PRESTADOR", r"ACTIVIDAD"]) is not None
        has_camas = cls._find_column(df, [r"CAMA", r"HABITAC", r"NUM.*EMP", r"EMPLEADO"]) is not None

        # Si tiene municipio y (categoría o camas/empleados), es la base cruda
        return has_municipio and (has_categoria or has_camas)

    @classmethod
    def aggregate_rnt(cls, df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Agrupa la base cruda del RNT por MUNICIPIO y calcula:
        - Total_Camas: suma de camas
        - Total_Habitaciones: suma de habitaciones (o aproximación si no existe)
        - Total_Empleados: suma de personal ocupado / empleados
        - Alojamiento: conteo de prestadores de hospedaje/alojamiento
        - Agencia: conteo de agencias de viajes / turismo
        - Gastronomía: conteo de establecimientos de gastronomía/bares
        """
        df_work = df.copy()
        original_rows = len(df_work)

        # 1. Identificar columnas clave
        col_muni = cls._find_column(df_work, [r"^MUNICIPIO", r"^CIUDAD", r"NOMBRE.*MUNI", r"^MPIO"])
        col_camas = cls._find_column(df_work, [r"CAMA", r"NUM.*CAMA", r"TOTAL.*CAMA"])
        col_hab = cls._find_column(df_work, [r"HABITAC", r"NUM.*HAB", r"TOTAL.*HAB"])
        col_emp = cls._find_column(df_work, [r"NUM.*EMP", r"EMPLEADO", r"PERSONAL", r"TOTAL.*EMP"])
        col_cat = cls._find_column(df_work, [r"^CATEGORIA", r"SUB.*CATEGORIA", r"TIPO.*PRESTADOR", r"ACTIVIDAD"])
        col_subcat = cls._find_column(df_work, [r"SUB.*CATEGORIA", r"ACTIVIDAD"])
        col_dane = cls._find_column(df_work, [r"COD.*MUNI", r"COD.*DANE", r"DANE", r"CODIGO.*MUNI"])
        col_estado = cls._find_column(df_work, [r"ESTADO", r"ESTADO.*RNT"])

        if not col_muni:
            raise ValueError("No se pudo identificar una columna de Municipio en la base cruda del RNT.")

        # 2. Filtrar por estado activo si la columna existe y tiene registros activos
        if col_estado:
            mask_activo = df_work[col_estado].astype(str).str.upper().str.contains("ACTIVO", na=False)
            if mask_activo.sum() > 0:
                df_work = df_work[mask_activo].copy()

        # 3. Limpiar Municipio
        df_work[col_muni] = df_work[col_muni].astype(str).str.strip().str.title()
        # Eliminar municipios vacíos o 'Nan'
        df_work = df_work[~df_work[col_muni].str.lower().isin(["nan", "none", "", "null"])].copy()

        # 4. Limpieza numérica de camas, habitaciones y empleados
        if col_camas:
            df_work["_camas"] = pd.to_numeric(df_work[col_camas], errors="coerce").fillna(0).clip(lower=0)
        else:
            df_work["_camas"] = 0

        if col_hab:
            df_work["_hab"] = pd.to_numeric(df_work[col_hab], errors="coerce").fillna(0).clip(lower=0)
        else:
            # Si no hay columna de habitaciones, aproximar según camas o default razonable
            df_work["_hab"] = (df_work["_camas"] / 2.0).round().clip(lower=0)

        if col_emp:
            df_work["_emp"] = pd.to_numeric(df_work[col_emp], errors="coerce").fillna(0).clip(lower=0)
        else:
            df_work["_emp"] = 1  # Al menos 1 empleado por establecimiento registrado

        # 5. Clasificar prestadores turísticos (Alojamiento, Agencia, Gastronomía)
        cat_text = ""
        if col_cat:
            cat_text = df_work[col_cat].astype(str)
        if col_subcat and col_subcat != col_cat:
            cat_text = cat_text + " " + df_work[col_subcat].astype(str)
        
        cat_normalized = cat_text.apply(normalize_text)

        # Reglas regex para clasificar prestadores
        pat_aloj = r"ALOJ|HOTEL|HOST|HOSP|VIVIENDA.*TUR|CAMPING|APARTA|POSADA|GLAMP|ECOHOTEL|ALBERGUE|RESIDENCIA"
        pat_agen = r"AGEN|VIAJE|TOUR|OPERADOR|GUIA|OFICINA.*REPRES|CENTRAL.*RESERVA"
        pat_gast = r"GASTRO|RESTAUR|BAR|CAFE|ALIMENT|BEBID|TABERNA|DISCO|PIZZ"

        df_work["_is_alojamiento"] = cat_normalized.str.contains(pat_aloj, regex=True).astype(int)
        df_work["_is_agencia"] = cat_normalized.str.contains(pat_agen, regex=True).astype(int)
        df_work["_is_gastronomia"] = cat_normalized.str.contains(pat_gast, regex=True).astype(int)

        # Si algún establecimiento con camas > 0 no fue clasificado, asumirlo como alojamiento
        mask_aloj_camas = (df_work["_camas"] > 0) & (df_work["_is_alojamiento"] == 0) & (df_work["_is_agencia"] == 0) & (df_work["_is_gastronomia"] == 0)
        df_work.loc[mask_aloj_camas, "_is_alojamiento"] = 1

        # 6. Agrupación por Municipio
        agg_dict = {
            "_camas": "sum",
            "_hab": "sum",
            "_emp": "sum",
            "_is_alojamiento": "sum",
            "_is_agencia": "sum",
            "_is_gastronomia": "sum"
        }

        if col_dane:
            agg_dict[col_dane] = "first"

        df_agg = df_work.groupby(col_muni, as_index=False).agg(agg_dict)

        # 7. Renombrar a los nombres oficiales del modelo
        rename_map = {
            col_muni: "Municipio",
            "_camas": "Total_Camas",
            "_hab": "Total_Habitaciones",
            "_emp": "Total_Empleados",
            "_is_alojamiento": "Alojamiento",
            "_is_agencia": "Agencia",
            "_is_gastronomia": "Gastronomía"
        }
        if col_dane:
            rename_map[col_dane] = "Codigo_DANE"

        df_agg.rename(columns=rename_map, inplace=True)

        # Convertir a enteros limpios
        int_cols = ["Total_Camas", "Total_Habitaciones", "Total_Empleados", "Alojamiento", "Agencia", "Gastronomía"]
        for c in int_cols:
            if c in df_agg.columns:
                df_agg[c] = pd.to_numeric(df_agg[c], errors="coerce").fillna(0).round().astype(int)

        # Ordenar por Municipio
        df_agg.sort_values(by="Municipio", inplace=True)
        df_agg.reset_index(drop=True, inplace=True)

        info = {
            "was_aggregated": True,
            "original_rows": original_rows,
            "filtered_active_rows": len(df_work),
            "aggregated_municipalities": len(df_agg),
            "detected_columns": {
                "municipio": col_muni,
                "camas": col_camas,
                "habitaciones": col_hab,
                "empleados": col_emp,
                "categoria": col_cat,
                "dane": col_dane
            }
        }

        return df_agg, info

    @classmethod
    def process_dataframe(cls, df: pd.DataFrame) -> Tuple[pd.DataFrame, bool, Dict[str, Any]]:
        """
        Función principal de entrada:
        - Si es crudo del RNT: ejecuta la agregación y retorna el DataFrame compatible.
        - Si ya está agregado: lo deja pasar directamente sin alteraciones.
        """
        if cls.is_raw_rnt(df):
            df_agg, info = cls.aggregate_rnt(df)
            return df_agg, True, info
        else:
            return df, False, {"was_aggregated": False}
