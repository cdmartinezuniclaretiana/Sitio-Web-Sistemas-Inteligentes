"""
Módulo de Reentrenamiento y Versionamiento de Modelos.
Entrena modelos candidatos, compara Accuracy contra el modelo activo en metadata.json,
y gestiona el versionamiento y archivado de artefactos serializados.
"""

import json
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np
import joblib

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

from backend.validation import DataValidator


class ModelTrainer:
    def __init__(self, metadata_path: str = None, models_dir: str = None):
        base_dir = Path(__file__).resolve().parent.parent
        self.metadata_path = Path(metadata_path) if metadata_path else base_dir / "models" / "metadata.json"
        self.models_dir = Path(models_dir) if models_dir else base_dir / "models"
        self.versions_dir = self.models_dir / "versiones"
        self.versions_dir.mkdir(parents=True, exist_ok=True)
        self.validator = DataValidator(str(self.metadata_path))

    def _load_metadata(self) -> Dict[str, Any]:
        with open(self.metadata_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _save_metadata(self, metadata: Dict[str, Any]):
        with open(self.metadata_path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)

    def _get_next_version_info(self, current_file: str, current_version: str) -> Tuple[str, str]:
        """Calcula el nombre del nuevo archivo (ej. model_v2.pkl) y la nueva versión semántica."""
        import re
        match_file = re.search(r"model_v(\d+)\.pkl", current_file)
        if match_file:
            next_num = int(match_file.group(1)) + 1
        else:
            next_num = 2
        next_filename = f"model_v{next_num}.pkl"

        parts = current_version.split(".")
        if len(parts) == 3 and parts[1].isdigit():
            next_version = f"{parts[0]}.{int(parts[1]) + 1}.0"
        else:
            next_version = f"v{next_num}.0.0"

        return next_filename, next_version

    def retrain(self, df: pd.DataFrame, test_size: float = 0.25, random_state: int = 42) -> Dict[str, Any]:
        """
        Ejecuta el flujo completo de reentrenamiento:
        1. Validación estricta con is_training=True.
        2. Extracción de variables requeridas y variable objetivo.
        3. Entrenamiento de Pipeline (Imputer + Scaler + RandomForest).
        4. Evaluación de métricas en conjunto de prueba.
        5. Comparación con el modelo activo.
        6. Versionamiento y actualización de metadata.json si el modelo nuevo es superior o igual.
        """
        # 1. Validación de compatibilidad para entrenamiento
        val_result = self.validator.validate_dataset(df, is_training=True)
        if not val_result["can_predict"]:
            return {
                "success": False,
                "status": "VALIDACION_FALLIDA",
                "message": "El dataset no cumple con las condiciones para entrenamiento.",
                "validation_errors": val_result["errors"],
                "validation_warnings": val_result["warnings"]
            }

        metadata = self._load_metadata()
        target_col = metadata.get("target_variable", "Servicio_Faltante")
        required_features = metadata.get("features", {}).get("required", [])
        current_metric_value = float(metadata.get("metric_value", 0.0))
        current_active_file = metadata.get("active_model_file", "model_v1.pkl")
        current_version = metadata.get("active_version", "1.0.0")

        # 2. Preparación de datos
        df_clean = df.dropna(subset=[target_col]).copy()
        X = df_clean[required_features].apply(pd.to_numeric, errors='coerce')
        y = df_clean[target_col].astype(str)

        # Verificar suficientes muestras por clase
        class_counts = y.value_counts()
        if len(class_counts) < 2 or (class_counts < 2).any():
            return {
                "success": False,
                "status": "DATOS_INSUFICIENTES",
                "message": f"Se requieren al menos 2 muestras por cada clase. Distribución actual: {class_counts.to_dict()}"
            }

        # Train/Test Split estratificado si es posible
        try:
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=random_state, stratify=y
            )
        except Exception:
            # Si alguna clase tiene muy pocas muestras para stratify
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size, random_state=random_state
            )

        # 3. Pipeline de entrenamiento
        pipeline = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("classifier", RandomForestClassifier(
                n_estimators=120,
                max_depth=8,
                random_state=random_state,
                class_weight="balanced"
            ))
        ])

        pipeline.fit(X_train, y_train)

        # 4. Evaluación
        y_pred = pipeline.predict(X_test)
        new_accuracy = round(float(accuracy_score(y_test, y_pred)), 4)
        report_dict = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
        labels = sorted(list(np.unique(np.concatenate([y_test, y_pred]))))
        cm = confusion_matrix(y_test, y_pred, labels=labels).tolist()

        timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 5. Comparación y Decisión de Versionamiento
        is_improved_or_equal = new_accuracy >= current_metric_value
        next_filename, next_version = self._get_next_version_info(current_active_file, current_version)

        if is_improved_or_equal:
            # Respaldar modelo activo previo en versiones/
            current_active_path = self.models_dir / current_active_file
            if current_active_path.exists():
                archive_path = self.versions_dir / f"backup_{current_version}_{current_active_file}"
                shutil.copy2(current_active_path, archive_path)

            # Guardar nuevo modelo
            new_model_path = self.models_dir / next_filename
            joblib.dump(pipeline, new_model_path)

            # Actualizar historial de versiones en metadata
            for v_entry in metadata.get("versions_history", []):
                if v_entry.get("status") == "activo":
                    v_entry["status"] = "historico"
                    v_entry["archived_at"] = timestamp_str

            new_history_entry = {
                "version": next_version,
                "filename": next_filename,
                "metric_name": "Accuracy",
                "metric_value": new_accuracy,
                "status": "activo",
                "timestamp": timestamp_str,
                "notes": f"Reentrenado con {len(df_clean)} registros. Accuracy previo: {current_metric_value} -> Nuevo: {new_accuracy}"
            }
            metadata.setdefault("versions_history", []).append(new_history_entry)

            # Actualizar metadata global
            metadata["active_model_file"] = next_filename
            metadata["active_version"] = next_version
            metadata["metric_value"] = new_accuracy
            metadata["last_updated"] = timestamp_str

            self._save_metadata(metadata)

            return {
                "success": True,
                "decision": "MODELO_ACTUALIZADO",
                "promoted": True,
                "message": (
                    f"¡Nuevo modelo promovido con éxito! Versión: {next_version} ({next_filename}). "
                    f"El Accuracy aumentó/igualó de {current_metric_value * 100:.2f}% a {new_accuracy * 100:.2f}%."
                ),
                "previous_version": current_version,
                "new_version": next_version,
                "previous_accuracy": current_metric_value,
                "new_accuracy": new_accuracy,
                "accuracy_delta": round(new_accuracy - current_metric_value, 4),
                "classification_report": report_dict,
                "confusion_matrix": {
                    "labels": labels,
                    "matrix": cm
                },
                "total_train_samples": len(X_train),
                "total_test_samples": len(X_test)
            }
        else:
            # Guardar candidato rechazado en carpeta de versiones para trazabilidad
            rejected_filename = f"candidato_rechazado_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pkl"
            joblib.dump(pipeline, self.versions_dir / rejected_filename)

            return {
                "success": True,
                "decision": "MODELO_RECHAZADO_MENOR_RENDIMIENTO",
                "promoted": False,
                "message": (
                    f"El modelo candidato obtuvo un Accuracy de {new_accuracy * 100:.2f}%, inferior al "
                    f"modelo activo actual ({current_metric_value * 100:.2f}%). Se mantiene activo '{current_active_file}' ({current_version})."
                ),
                "active_version": current_version,
                "active_accuracy": current_metric_value,
                "candidate_accuracy": new_accuracy,
                "accuracy_delta": round(new_accuracy - current_metric_value, 4),
                "classification_report": report_dict,
                "confusion_matrix": {
                    "labels": labels,
                    "matrix": cm
                },
                "archived_candidate_file": rejected_filename
            }
