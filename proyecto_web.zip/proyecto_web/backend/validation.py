"""
Módulo de Validación de Datos para el Sistema de Machine Learning.
Valida esquema, tipos de datos, valores nulos y reglas de dominio según models/metadata.json.
"""

import json
from pathlib import Path
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np


class DataValidator:
    def __init__(self, metadata_path: str = None):
        if metadata_path is None:
            # Ruta relativa estándar dentro del proyecto
            base_dir = Path(__file__).resolve().parent.parent
            metadata_path = base_dir / "models" / "metadata.json"
        
        self.metadata_path = Path(metadata_path)
        self.metadata = self._load_metadata()

    def _load_metadata(self) -> Dict[str, Any]:
        """Carga y retorna los metadatos del modelo."""
        if not self.metadata_path.exists():
            raise FileNotFoundError(f"No se encontró el archivo de metadatos en: {self.metadata_path}")
        with open(self.metadata_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def reload_metadata(self):
        """Recarga los metadatos desde el disco."""
        self.metadata = self._load_metadata()

    def validate_dataset(self, df: pd.DataFrame, is_training: bool = False) -> Dict[str, Any]:
        """
        Ejecuta las 4 fases de validación:
        1. Esquema
        2. Tipos de datos
        3. Contenido (Nulos y duplicados)
        4. Reglas de Dominio (Rangos lógicos)

        Retorna un diccionario con estado ("COMPATIBLE", "COMPATIBLE CON ADVERTENCIAS", "INCOMPATIBLE").
        """
        errors = []
        warnings = []
        details = {
            "total_rows": int(len(df)),
            "total_columns": int(len(df.columns)),
            "detected_columns": list(df.columns),
            "missing_required_columns": [],
            "extra_columns": [],
            "type_errors": {},
            "null_summary": {},
            "domain_violations": {}
        }

        # 0. Validación de tamaño mínimo
        if len(df) == 0:
            errors.append("El archivo está completamente vacío. No contiene registros.")
            return {
                "status": "INCOMPATIBLE",
                "can_predict": False,
                "errors": errors,
                "warnings": warnings,
                "details": details
            }

        required_features = self.metadata.get("features", {}).get("required", [])
        expected_types = self.metadata.get("features", {}).get("types", {})
        nullable_rules = self.metadata.get("features", {}).get("nullable", {})
        ranges_rules = self.metadata.get("features", {}).get("ranges", {})
        target_col = self.metadata.get("target_variable", "Servicio_Faltante")
        target_classes = self.metadata.get("target_classes", [])
        excluded_vars = set(self.metadata.get("excluded_variables", []))

        # --- 1. VALIDACIÓN DE ESQUEMA ---
        missing_cols = [col for col in required_features if col not in df.columns]
        if missing_cols:
            details["missing_required_columns"] = missing_cols
            errors.append(f"Faltan columnas requeridas obligatorias: {', '.join(missing_cols)}")

        if is_training:
            if target_col not in df.columns:
                errors.append(f"Para reentrenamiento es obligatoria la variable objetivo '{target_col}'.")
            else:
                # Validar categorías del target
                unique_targets = df[target_col].dropna().unique()
                invalid_classes = [c for c in unique_targets if c not in target_classes]
                if invalid_classes:
                    errors.append(
                        f"La columna '{target_col}' contiene clases no reconocidas: {invalid_classes}. "
                        f"Clases permitidas: {target_classes}"
                    )

        # Detectar columnas adicionales
        extra_cols = [col for col in df.columns if col not in required_features and col != target_col]
        details["extra_columns"] = extra_cols
        unrecognized_extras = [c for c in extra_cols if c not in excluded_vars]
        if unrecognized_extras:
            warnings.append(
                f"Se detectaron columnas adicionales no requeridas para el modelo: {', '.join(unrecognized_extras)}. "
                "Serán ignoradas durante la inferencia."
            )

        # Si faltan columnas requeridas, no podemos continuar con tipos y rangos de esas columnas
        available_features = [col for col in required_features if col in df.columns]

        # --- 2. VALIDACIÓN DE TIPOS ---
        for col in available_features:
            exp_type = expected_types.get(col, "numeric")
            if exp_type == "numeric":
                # Intentar convertir a numérico
                numeric_converted = pd.to_numeric(df[col], errors='coerce')
                # Contar cuántos valores se convirtieron en NaN que antes no eran NaN
                invalid_type_count = int((numeric_converted.isna() & df[col].notna()).sum())
                if invalid_type_count > 0:
                    details["type_errors"][col] = invalid_type_count
                    errors.append(
                        f"La columna numérica '{col}' contiene {invalid_type_count} registro(s) con texto o formato no numérico."
                    )

        # --- 3. VALIDACIÓN DE CONTENIDO (NULOS) ---
        for col in available_features:
            null_count = int(df[col].isna().sum())
            details["null_summary"][col] = null_count
            can_be_null = nullable_rules.get(col, False)

            if null_count > 0:
                pct = (null_count / len(df)) * 100
                if not can_be_null:
                    if pct > 25:
                        errors.append(
                            f"La columna obligatoria '{col}' contiene {null_count} nulos ({pct:.1f}% del total). "
                            "Supera el umbral crítico para predicción confiable."
                        )
                    else:
                        warnings.append(
                            f"La columna '{col}' contiene {null_count} valor(es) nulo(s) ({pct:.1f}%). "
                            "Se recomienda imputación o limpieza antes de inferir."
                        )

        if is_training and target_col in df.columns:
            target_nulls = int(df[target_col].isna().sum())
            if target_nulls > 0:
                errors.append(f"La columna objetivo '{target_col}' contiene {target_nulls} nulos. No es admisible para reentrenamiento.")

        # --- 4. VALIDACIÓN DE DOMINIO (RANGOS LÓGICOS) ---
        for col in available_features:
            if col in ranges_rules and col not in details["type_errors"]:
                col_numeric = pd.to_numeric(df[col], errors='coerce').dropna()
                min_rule = ranges_rules[col].get("min", None)
                max_rule = ranges_rules[col].get("max", None)

                negatives = (col_numeric < 0).sum()
                if negatives > 0:
                    errors.append(f"La columna '{col}' contiene {negatives} valor(es) negativos, lo cual es físicamente imposible.")

                if min_rule is not None:
                    out_min = int((col_numeric < min_rule).sum())
                    if out_min > 0:
                        details["domain_violations"][f"{col}_menor_a_{min_rule}"] = out_min

                if max_rule is not None:
                    out_max = int((col_numeric > max_rule).sum())
                    if out_max > 0:
                        details["domain_violations"][f"{col}_mayor_a_{max_rule}"] = out_max
                        warnings.append(
                            f"La columna '{col}' tiene {out_max} valor(es) inusualmente altos (> {max_rule})."
                        )

        # --- DETERMINACIÓN DEL ESTADO FINAL ---
        if len(errors) > 0:
            status = "INCOMPATIBLE"
            can_predict = False
        elif len(warnings) > 0:
            status = "COMPATIBLE CON ADVERTENCIAS"
            can_predict = True
        else:
            status = "COMPATIBLE"
            can_predict = True

        return {
            "status": status,
            "can_predict": can_predict,
            "errors": errors,
            "warnings": warnings,
            "details": details
        }
