"""
Módulo del Pipeline de Machine Learning para Inferencia.
Carga el modelo activo especificado en metadata.json y realiza predicciones
estrictamente con métodos de inferencia (sin reajustar transformadores).
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Tuple
import pandas as pd
import joblib


class MLPredictor:
    def __init__(self, metadata_path: str = None, models_dir: str = None):
        base_dir = Path(__file__).resolve().parent.parent
        self.metadata_path = Path(metadata_path) if metadata_path else base_dir / "models" / "metadata.json"
        self.models_dir = Path(models_dir) if models_dir else base_dir / "models"
        self.reports_dir = base_dir / "reports"
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        
        self.model = None
        self.active_filename = None
        self.active_version = None
        self.required_features = []
        self._load_active_model()

    def _load_metadata(self) -> Dict[str, Any]:
        with open(self.metadata_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _load_active_model(self):
        """Carga el modelo serializado activo según metadata.json."""
        meta = self._load_metadata()
        active_file = meta.get("active_model_file", "model_v1.pkl")
        self.active_version = meta.get("active_version", "1.0.0")
        self.required_features = meta.get("features", {}).get("required", [])

        model_path = self.models_dir / active_file
        if not model_path.exists():
            raise FileNotFoundError(
                f"El archivo del modelo activo '{active_file}' no existe en {self.models_dir}."
            )

        self.model = joblib.load(model_path)
        self.active_filename = active_file

    def reload(self):
        """Recarga el modelo activo tras un reentrenamiento o actualización."""
        self._load_active_model()

    def predict(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any], str]:
        """
        Ejecuta la inferencia sobre el dataframe suministrado:
        - Conserva todas las columnas originales (incluyendo identificadores como Municipio o ID).
        - Extrae las features obligatorias en el orden exacto esperado por el modelo.
        - Aplica predict y predict_proba del pipeline precargado (SIN FIT).
        - Guarda una copia con timestamp en la carpeta reports/.
        - Retorna: (df_con_predicciones, métricas_resumen, ruta_archivo_csv)
        """
        if self.model is None:
            self._load_active_model()

        # Verificar que existan las features requeridas
        missing = [f for f in self.required_features if f not in df.columns]
        if missing:
            raise ValueError(f"Faltan variables para ejecutar la inferencia: {missing}")

        # Copia de trabajo para no alterar el DataFrame original
        df_result = df.copy()

        # Seleccionar features requeridas en el orden estricto
        X = df_result[self.required_features].copy()

        # Asegurar tipos numéricos para la inferencia
        for col in self.required_features:
            X[col] = pd.to_numeric(X[col], errors='coerce').fillna(0)

        # Inferencia estricta sin refit
        predictions = self.model.predict(X)
        df_result["Prediccion_Servicio_Faltante"] = predictions

        # Probabilidades y nivel de confianza
        confidence_scores = []
        if hasattr(self.model, "predict_proba"):
            try:
                probabilities = self.model.predict_proba(X)
                classes = list(self.model.classes_)
                # Agregar probabilidad por clase
                for i, cls_name in enumerate(classes):
                    col_name = f"Prob_{cls_name}"
                    df_result[col_name] = probabilities[:, i].round(4)
                
                # Nivel de confianza (la probabilidad más alta de la clase predicha)
                max_probs = probabilities.max(axis=1)
                df_result["Confianza_Prediccion"] = (max_probs * 100).round(2)
                confidence_scores = max_probs.tolist()
            except Exception:
                pass

        # Generar resumen analítico de las predicciones garantizando las 3 clases en el conteo
        raw_counts = df_result["Prediccion_Servicio_Faltante"].value_counts().to_dict()
        expected_classes = ["Alojamiento", "Agencia", "Gastronomía"]
        class_distribution = {cls_name: int(raw_counts.get(cls_name, 0)) for cls_name in expected_classes}
        # Incluir cualquier otra clase si existiera
        for k, v in raw_counts.items():
            if k not in class_distribution:
                class_distribution[k] = int(v)

        avg_confidence = float(df_result["Confianza_Prediccion"].mean()) if "Confianza_Prediccion" in df_result else 0.0

        summary = {
            "total_predicciones": len(df_result),
            "modelo_utilizado": self.active_filename,
            "version_modelo": self.active_version,
            "distribucion_clases": class_distribution,
            "confianza_promedio_pct": round(avg_confidence, 2),
            "fecha_inferencia": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        # Guardar archivo en reports/
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_filename = f"predicciones_{timestamp}.csv"
        report_path = self.reports_dir / report_filename
        df_result.to_csv(report_path, index=False, encoding="utf-8")

        return df_result, summary, report_filename
