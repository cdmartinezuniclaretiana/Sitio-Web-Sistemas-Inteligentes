import sys
from pathlib import Path

# Agregar raíz al sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd
from backend.validation import DataValidator
from backend.ml_pipeline import MLPredictor
from backend.train import ModelTrainer

print(">>> Probando DataValidator...")
val = DataValidator()
df_pred = pd.read_csv("data/sample_para_predecir.csv")
res_val = val.validate_dataset(df_pred)
print("Estado validación (sample_para_predecir):", res_val["status"])

df_incomp = pd.read_csv("data/sample_incompatible.csv")
res_incomp = val.validate_dataset(df_incomp)
print("Estado validación (sample_incompatible):", res_incomp["status"])
print("Errores incompatibles:", res_incomp["errors"])

print("\n>>> Probando MLPredictor...")
predictor = MLPredictor()
df_res, summary, report_file = predictor.predict(df_pred)
print("Predicciones completadas. Resumen:", summary)
print("Reporte generado:", report_file)
print("Primeras 3 filas:")
print(df_res[["Municipio", "Total_Camas", "Prediccion_Servicio_Faltante", "Confianza_Prediccion"]].head(3))

print("\n>>> Probando ModelTrainer (Reentrenamiento)...")
trainer = ModelTrainer()
df_retrain = pd.read_csv("data/sample_para_reentrenar.csv")
retrain_res = trainer.retrain(df_retrain)
print("Decisión de reentrenamiento:", retrain_res.get("decision"))
print("Mensaje:", retrain_res.get("message"))
print("Pruebas finalizadas con éxito!")
